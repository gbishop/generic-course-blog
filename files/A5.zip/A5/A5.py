#Assignment 5
#Name:
#Collaborators:
#Due 25 February 2011

import numpy as np
import pylab

# some helpers to load and save images
def load_binary_image(name):
    '''Load a binary image from a file'''
    im = pylab.imread(name)
    if im.ndim == 3:
        result = im[:,:,0] != 0
    elif im.ndim == 2:
        result = im != 0
    return result

def save_binary_image(name, value):
    '''Save a binary image to a file'''
    import scipy
    scipy.misc.imsave(name, value)

# load the test image we'll use below
test_image = load_binary_image('test.png')

# 1. Scroll images.

# define your functions to scroll images

def scrollLeft(img, amt):
    '''Return a new image that is the given image scrolled left by amt pixels'''
    new = np.zeros_like(img)
    # do something to fill in values in new here

    return new

# similarly define the rest of them.

def scrollRight(img, amt):
    '''Return a new image that is the given image scrolled right by amt pixels'''
    return new

def scrollUp(img, amt):
    '''Return a new image that is the given image scrolled up by amt pixels'''
    return new

def scrollDown(img, amt):
    '''Return a new image that is the given image scrolled down by amt pixels'''
    return new

# 1A. scroll the image up by 10 pixels.
up10 = scrollUp(test_image, 10)
# and save that
save_binary_image('1A.png', up10)

# 1B. now scroll the result of 1A down by 10 pixels.
updown10 = scrollDown(up10, 10)
# and save that
save_binary_image('1B.png', updown10)

# 1C. Do they look the same? Why or why not?

# answer here in this comment

# 1D. Scroll the test image left by half its width

# save it in 1D.png as above

# 1E. and then scroll that result back to the right by the same amount.

# save in 1E.png.

# 2. Boundary Detector

def findBoundary(img):
    '''Return an image that is one for boundary pixels and zero elsewhere'''
    # compute the result of finding the boundary here
    return result

# show the boundary of the test image

boundary = findBoundary(test_image)
save_binary_image('2.png', boundary)

# 3. Dilate and Erode

def dilateImage(img):
    '''Return an image that is the dilation of the input img'''

    # compute the dilation here
    return result

def erodeImage(img):
    '''Return an image that is the erosion of the input img'''

    # compute the value into result
    return result

# 3A dilate the test image, then dilate that result, then dilate that result so you have
# three dilations. So the final result.

D3 = dilateImage(dilateImage(dilateImage(test_image)))
save_binary_image('3A.png', D3)

E3 = erodeImage(erodeImage(erodeImage(test_image)))
save_binary_image('3B.png', E3)

E3D3 = dilateImage(dilateImage(dilateImage(E3)))
save_binary_image('3C.png', E3D3)

# 3D. Find the boundary of the original image, and then dilate the boundary image.  Save the result.

# save as 3D.png

# 3E. Then take the original image, dilate it once, and then find its boundary.  Save the result.

# save as 3E.png

# 3F. Describe the difference between the two images. 

# put your description here as a comment.
