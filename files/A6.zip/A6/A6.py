import numpy as np
import pylab
from mpl_toolkits.mplot3d import Axes3D

# I have marked the places where you must insert code with #+++

def readPDBfile(filename):
    '''read a PDB file, extract the ATOM lines, and return
       atom number, atom name, residue number, and coords for each'''
    # build them up in lists because they are cheap to append
    anum = []
    aname = []
    resno = []
    coords = []
    # open the file and process each line
    
    #+++ your work goes here. You should read the ATOM lines and append the appropriate
    #+++ fields to anum, aname, resno, and coords

    # convert the results to numpy arrays
    anum = np.array(anum)
    aname = np.array(aname)
    coords = np.array(coords)
    resno = np.array(resno)

    # return the 4 results
    return (anum, aname, resno, coords)

def drawCA(aname, coords):
    '''plot the Calpha backbone of an atom'''
    fig = pylab.figure()

    #+++ your work goes here
    
    return fig

# here is a helper I wrote to make your job easier in Hbonds
def atomType(aname):
    '''Get the 2nd character of all the atom names'''
    # this is trickier than it should, ideally, be. Unfortunately, numpy arrays of
    # strings don't slice like (I think) they should. So I'm converting the array of
    # strings to an array of characters view(), reshaping that flattened result into a
    # 2D array of characters N x 4. Extracting the character at index 1 from each of them.
    return aname.view(dtype='S1').reshape((-1,4))[:,1]

def Hbonds(anum, aname, resno, coords):
    '''Find hydrogen bonds'''
    pairs = [] # build up the result in this list

    #+++ your work goes here
    
    return pairs

# now test our functions to see that they do the right thing

for protein in ['7HVP', '1GFL']:
    # extract the data on the atoms from the pdb file
    num, name, rn, c = readPDBfile(protein + '.pdb')

    # draw the Calpha backbone
    fig = drawCA(name, c)
    # save it in a file
    fig.savefig(protein+'.png')

    # get the list of hydrogen bonding pairs
    hydrogen_bonding_pairs = Hbonds(num, name, rn, c)

    # and report the number
    print 'number of hydrogen bonding pairs in', protein, 'is', len(hydrogen_bonding_pairs)
    
